<div id="dropDownSelect1"></div>

<!--===============================================================================================-->
<script src="<?= base_url('assets/Login_v4/') ?>vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/Login_v4/') ?>vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/Login_v4/') ?>vendor/bootstrap/js/popper.js"></script>
<script src="<?= base_url('assets/Login_v4/') ?>vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/Login_v4/') ?>vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/Login_v4/') ?>vendor/daterangepicker/moment.min.js"></script>
<script src="<?= base_url('assets/Login_v4/') ?>vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/Login_v4/') ?>vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
<script src="<?= base_url('assets/Login_v4/') ?>js/main.js"></script>

</body>

</html>